#include "../h/c/Process.h"

int Process_GetProcessId(const char* processName)
{
    return 0;
}
