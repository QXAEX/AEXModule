#pragma once
#include <windows.h>
#include <string>
#include <vector>
#include "Text.h"
#include "Byteset.h"
#include "./Gui/WinGui.h"
#include "./Gui/WinGuiPlus.h"
namespace Gui {
    //winԭ��gui
    namespace WinGui =  WinGui;
    //winԭ��gui+
    namespace WinGuiPlus =  WinGuiPlus;
}
