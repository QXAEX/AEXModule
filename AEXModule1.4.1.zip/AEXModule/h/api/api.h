#pragma once
#include "./data/ntdll.h"
#include "./data/kernel32.h"
namespace API {
	using namespace NTDLL;
	using namespace KERNEL32;
};